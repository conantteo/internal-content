from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import os
from dotenv import load_dotenv
import json
import requests
from fastapi.responses import StreamingResponse
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import START, MessagesState, StateGraph
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
import urllib.parse
import re


load_dotenv()

API_KEY = os.getenv("API_KEY")
MODEL_NAME = os.getenv("MODEL_NAME")

# Prompts
ITERATIVE_PROMPT = """\
You are an AI assistant that helps users fill out a form by extracting structured information from their free-text responses.
* Never reveal your chain-of-thought, internal reasoning, checklists, or step-by-step logic.
* Only output either: A single plain-English question prompting the user for all missing/invalid fields or, when you have all required & validated values, output exactly Done! followed immediately by the JSON object (no extra text of commentary)

1. Let FIELDS be the full list of all field names for this form:
    {fields_list}

2. Let REQUIRED be the subset of FIELDS that must be non-empty (or non-zero) before returning a JSON:
    {required_list}

3. If any field in REQUIRED is still empty ("" or 0), do NOT output any JSON object. Instead, ask exactly for the missing field(s), one at a time, in plain language. For example:
   • If “{required_list}” is missing, ask “Please provide {required_list}.”
   • If multiple required fields are missing, ask about whichever one is most logical next.  
   Do not mention JSON or your internal logic—just ask the user for the missing piece of data.

4. Only when all names in REQUIRED have non-empty, non-zero values should you output a JSON object with keys exactly matching FIELDS. The JSON must use this schema (no extra keys, no wrapped text, no comments):
    {json_schema_example}

5. Do not guess or assume any field. If you are not 100% sure the user's answer for a field is valid, leave it blank and ask a clarifying question.

6. Do not include the thinking and logical reasoning process in the output.

7. Once all required fields are filled, include a "DONE" at the start of the return text followed by the JSON object with no other additional text around it.
"""

DATA_VALIDATION_PROMPT = """\
On top of extracting fields, you are a data validation assistant for this form. 
For each field in FIELDS:
  • If the user's free-text response clearly cannot be a valid value for that field, you must leave it blank and ask a validation question instead.  
    - e.g. If field is “Age” and user says “three hundred,” ask “Please provide age as a number.”  
    - If field is “Country” and user says “Atlantis,” ask “I'm not sure 'Atlantis' is a real country. Please provide a valid country name.”  
  • Only once a field's value passes your validation should you accept it without further questioning.

You must never output a partial JSON if ANY required field is invalid or missing; instead, keep asking until it is valid.
"""

TASK_PROMPT = """\
For each individual field name (from FIELDS) and a piece of user free-text:
  • If the free-text clearly contains a valid value for that field, return exactly that valid value.  
  • If the free-text does not contain a valid or recognized value, return an empty string ("") for text fields or 0 for integer fields.  
Always interpret the field name literally. Do not guess or fill in anything you cannot confirm from the user's text.
"""

GUIDELINE_PROMPT = """\
Always interpret each field name literally. For example:
  • If field is “Country,” the value must match a real, recognized country name (e.g. “France,” “Brazil”).  
  • If field is “Email,” the value must contain an “@” and a valid domain structure.  
  • If field is “Age,” the value must be a positive integer.  
If you cannot confirm the value is valid, leave it blank ("" for text, 0 for integer) and ask a follow-up question.
"""

EXAMPLE_PROMPT = """\
Examples of how to handle incomplete vs. complete data:

1) Suppose FIELDS = [“FullName”, “Email”, “Age”] and REQUIRED = [“FullName”, “Email”].
   • User: “My name is Alice Johnson.”
     - AI: “What is your email?”
     (Do NOT output any JSON yet because Email is missing.)

   • User: “My email is alice@example.com.”
     - AI: “Please provide your age.”  
     (FullName and Email are valid, but Age is not required.)

   • User: “Age is 30.”
     - AI:  
       {
         "FullName": "Alice Johnson",
         "Email": "alice@example.com",
         "Age": 30
       }  

2) Suppose FIELDS = [“City”, “Country”, “Population”] and REQUIRED = [“City”, “Country”].
   • User: “I live in Metropolis.”
     - AI: “What is the country?”  
     (Country is required, so do not output any JSON yet.)

   • User: “Country is USA.”  
     - AI:  
       {
         "City": "Metropolis",
         "Country": "USA",
         "Population": 0
       }  
     (Population was not required, so it can be 0 if missing.)

3) Example of what NOT to do:
   • User: “My job is teacher, and I am from Narnia.”  
     - AI (wrong):  
       { "Job": "teacher", "Country": "Narnia" }  
     Because “Narnia” is not a valid country, the AI must ask “I'm not sure 'Narnia' is a valid country. Please provide a real country name” instead of returning JSON.
"""

FORM_SPECIFIC_PROMPT = """\
The form has these fields (FIELDS):
  {fields_list}

Required fields (REQUIRED) that must be non-empty before returning JSON:
  {required_list}

When all REQUIRED fields are filled with valid values, return exactly one JSON object with keys:
  {fields_list_json}
and matching values from the user. Include a text saying "Done!" at the beginning with no other text surrounding the JSON object. 
If any REQUIRED field is missing or invalid, do NOT return JSON—ask a follow-up question instead.
"""

FORM_SCHEMAS = {
    "cityForm": {
        "fields": ["cityName", "country", "population", "area", "timezone", "major event"],
        "required": ["cityName", "country", "population", "area", "timezone"],
    },
}

schema = FORM_SCHEMAS["cityForm"]

fields_list     = ", ".join(schema["fields"])
required_list   = ", ".join(schema["required"])
fields_list_json = json.dumps(schema["fields"], indent=2)

iterative_prompt_filled = ITERATIVE_PROMPT.format(
    fields_list = fields_list,
    required_list = required_list,
    json_schema_example = "{\n  " +
      ",\n  ".join(f'"{f}": <value>' for f in schema["fields"]) +
      "\n}"
)

form_specific_prompt_filled = FORM_SPECIFIC_PROMPT.format(
    fields_list = fields_list,
    required_list = required_list,
    fields_list_json = fields_list_json
)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class PromptRequest(BaseModel):
    user_input: str

def build_prompt(history_messages: list[str], new_input: str) -> str:
    system = (iterative_prompt_filled + DATA_VALIDATION_PROMPT + TASK_PROMPT + GUIDELINE_PROMPT + EXAMPLE_PROMPT + form_specific_prompt_filled).strip()
    total = [system] + history_messages + [new_input]
    return "\n\n".join(total)

def call_model(state: MessagesState) -> dict:
    history = [m.content for m in state["messages"]]
    prompt = build_prompt(history, "")

    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "stream": False,
        "keep_alive": 0
    }
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }

    resp = requests.post(
        "http://localhost:11434/api/generate",
        json=payload,
        headers=headers,
    )
    resp.raise_for_status()
    text = resp.json().get("response", "")
    ai_msg = AIMessage(content=text)
    return {"messages": state["messages"] +[ai_msg]}

def build_prompt_test(history_messages: list[str], new_input: str) -> str:
        test_system = SystemMessage(content="""
        System:
        You are an AI assistant that helps users fill out a form by extracting structured information from their free-text responses.
        * Never reveal your chain-of-thought, internal reasoning, checklists, or step-by-step logic.
        * Only output either: A single plain-English question prompting the user for all missing/invalid fields or, when you have all required & validated values, output exactly Done! followed immediately by the JSON object (no extra text of commentary)
        Do **not** auto-fill defaults. If any required field is blank or invalid, you must **ask** for it explicitly.
                                                                
        Your task is to extract information from user input and fill out one of two forms based on the context provided.
        The user will provide free-text input that may relate to either a city form or a user profile form.
        In the event that the user input does not match either form, you inform the user that the input given is invalid.
                                
        There are two forms:

        **Form A (city):**  
        - cityName (string, required)  
        - country (string, required)  
        - population (number, required)  
        - area (number, required)  
        - timezone (string, required)  
        - majorEvent (string, optional)  

        **Form B (user profile):**  
        - firstName (string, required)  
        - lastName (string, required)  
        - email (string, required)  
        - phoneNumber (string, optional)  
        - address (string, optional)  
        - dateOfBirth (date, required)  
                                
        **Behavior rules:**
        1. Determine which form (A or B) the user is supplying.  
        2. If input matches neither form, respond:  
          `Input invalid. Please give details for either the city form or the user profile form.`  
        3. If any required field remains empty("") or invalid, ask one question listing all of the missing/invalid fields.
        4.  Always keep track of which required fields have already been provided by the user.  
            • Before asking a new question, check your memory of answers.  
            • Only ever ask for the *all* required field that remains empty or invalid.  
            • Do **not** repeat a question about any field once it has a valid value.  
        5. Note to never reveal your internal reasoning or chain-of-thought. Only output either:
          a. A single plain-English question prompting the user for all missing/invalid fields, or
          b. When you have all required & validated values, output exactly `DONE: formA` or `DONE: formB` followed immediately by the JSON object (no extra text of commentary).
        6. Once *all* required fields are present and valid, output:  
        ```
        DONE: formA
        {
            "cityName": "<value>",
            "country": "<value>",
            "population": <value>,
            "area": <value>,
            "timezone": "<value>",
            "majorEvent": "<value>"
        }
        ```
        or
        ```
        DONE: formB
        {
            "firstName": "<value>",
            "lastName": "<value>",
            "email": <value>,
            "phoneNumber": "<value>"
            "address": "<value>",
            "dateOfBirth": "<value>"
        }
        ```
                                    
        **Few-Shot Examples:**

        1)  
        User: “I live in Singapore, population five million, area 728.6.”  
        AI: “What is the name of this city?”  

        2)  
        User: “My name is John Doe”  
        AI: “What is your email and date of birth?”  

        3)  
        User: “Football is the best sport.”  
        AI: “Input invalid. Please give details for either the city form or the user profile form.”
                                    
        "These examples are for reference only. Do not output them in your response."
        /no_think
        """.strip())
        return "\n\n".join([test_system.content] + history_messages + [new_input])

def call_model_test(state: MessagesState) -> dict:
    history = [m.content for m in state["messages"]]
    prompt = build_prompt_test(history, "")

    payload = {
        "model": MODEL_NAME,
        "prompt": prompt,
        "response_format": { "type": "json_object" },
        "stream": False,
        "keep_alive": 0,
    }
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_KEY}"
    }

    resp = requests.post(
        "http://localhost:11434/api/generate",
        json=payload,
        headers=headers,
    )
    resp.raise_for_status()
    text = resp.json().get("response", "")
    text = re.sub(r"</?think>", "", text).strip()
    ai_msg = AIMessage(content=text)
    return {"messages": state["messages"] + [ai_msg]}

def sink_node(state: MessagesState) -> MessagesState:
    return {"messages": state["messages"]}

workflow = StateGraph(state_schema=MessagesState)
workflow.add_node("model", call_model)
workflow.add_node("sink", sink_node)
workflow.add_edge(START, "model")

memory_saver = MemorySaver()
app_graph = workflow.compile(checkpointer=memory_saver)

workflow_test = StateGraph(state_schema=MessagesState)
workflow_test.add_node("model", call_model_test)
workflow_test.add_node("sink", sink_node)
workflow_test.add_edge(START, "model")

memory_saver_test = MemorySaver()
app_graph_test = workflow_test.compile(checkpointer=memory_saver_test)

@app.post("/generate")
def generate(data: PromptRequest, stream: bool = Query(False, description="Whether to stream the response")):
    if not stream:
        human = HumanMessage(content=data.user_input)
        result = app_graph.invoke(
            {"messages": [human]},
            config={"configurable": {"thread_id": "default"}},
        )

        msgs = result["messages"]
        print(msgs)
        ai_last = next(m for m in reversed(msgs) if isinstance(m, AIMessage))

        if ai_last.content.startswith("Done!"):
          ai_last.content = ai_last.content[5:].strip()
          try:
              data = json.loads(ai_last.content)
          except json.JSONDecodeError:
              raise HTTPException(status_code=400, detail="Invalid JSON format in response")
          print(data)
          return f"http://localhost:3000/form?data={urllib.parse.quote(json.dumps(data))}"
        else:
          return ai_last.content
    else:
        return generate_stream(data)

def generate_stream(data: PromptRequest):
    human = HumanMessage(content=data.user_input)
    result = app_graph.invoke(
        {"messages": [human]},
        config={"configurable": {"thread_id": "default", "node_name": "sink"}},
    )
    msgs = result["messages"]
    history_texts = [m.content for m in msgs]
    full_prompt = build_prompt(history_texts, data.user_input)

    try:
        upstream = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": MODEL_NAME,
                "prompt": full_prompt,
                "stream": True,
                "keep_alive": 0
            },
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {API_KEY}"
            },
            stream=True
        )
        upstream.raise_for_status()
    except requests.RequestException as e:
        raise HTTPException(status_code=502, detail=f"Request failed: {str(e)}")
    
    def event_stream():
        full_ai_response = ""
        for line in upstream.iter_lines():
            if not line:
                continue
            try:
                data = json.loads(line.decode('utf-8'))
                chunk = data.get("response", "")
                full_ai_response += chunk
                yield chunk
            except json.JSONDecodeError:
                continue

        ai_msg = AIMessage(content=full_ai_response)
        app_graph.invoke(
            {"messages": msgs + [ai_msg]},
            config={"configurable": {"thread_id": "default", "node_name": "sink"}},
        )

    return StreamingResponse(event_stream(), media_type="text/plain")

@app.get("/form")
async def get_form(data: str = Query(..., description="URL-encoded JSON")):
    try:
        defaults = json.loads(data)
    except json.JSONDecodeError:
        raise HTTPException(400, detail="Invalid JSON in `data` parameter")
    return defaults

@app.post("/test")
def test_endpoint(data: PromptRequest):    
    human = HumanMessage(content=data.user_input)
    result = app_graph_test.invoke(
        {"messages": [human]},
        config={"configurable": {"thread_id": "default"}},
    )

    msgs = result["messages"]
    print(msgs)
    ai_msg = next(m for m in reversed(msgs) if isinstance(m, AIMessage))
    return ai_msg.content