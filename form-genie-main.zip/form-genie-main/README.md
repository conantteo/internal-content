# Form Genie

FormGenie is an AI-powered tool designed to streamline the process of filling out web forms by leveraging Large Language Models (LLMs). It intelligently generates structured JSON data required for forms, prompts users for any missing required fields, and ensures that all necessary information is collected before submission.

## Problem

Filling out web forms can be tedious, especially when users miss required fields or input data in the wrong format. Traditional forms often return generic error messages, leading to frustration and incomplete submissions.

Form Genie solves this by:

- Using LLMs to interpret user input and generate structured JSON data for forms.
- Detecting missing or incomplete required fields.
- Conversationally prompting users for only the information that is missing.
- Ensuring all required data is collected before filling up the web forms.

This approach creates a smoother, more intuitive experience for users and reduces form abandonment rates.

## Project Description

There will be multiple milestones to this project which will be discussed below.

### Ideal Scenario

A short ideal scenario is:

```
User prompts to fill up XXX form with the following details YYY.
A url link to auto-fill form will be generated if no other information is required.
If additional information is required, prompt user for additional information
```

### Milestone 1: Working with LLMs

A user is required to fill in forms on a web page using unstructured data that are gathered from various sources such as his own notes, a web page, or a word document etc.

In this problem, we are helping user to fill up information regarding cities in the world. There are a list of fields, note the ones marked in asterik are required:
- Name*
- Population
- Timezone*
- Country*
- Major Events

You can consider cities as reference data from online resources e.g. wiki:
- [Tokyo](https://en.wikipedia.org/wiki/Tokyo)

**Design a LLM prompt that will output structured data for the given context & user input**

Additional notes:
- You should think what is the best way to formulate your prompt
- Output data should be easy to parse as you will be using it later
- A web UI will be required for presentation purposes

### Milestone 2: AI Workflow

You should imagine this AI workflow as a chat bot conversation between user and the server.

**Design a backend server that receives the user input and output the answer from Milestone 1. You will need to keep the conversation going iteratively as the answer from the server could be asking for additional values to the required field(s).**

Additional notes:
- A form can only be completed if all the required fields are present during submission. You should ensure that all the fields are interpreted as accurately as possible & the user has provided all the necessary information before the final output.
- A chat bot conversation should have chat history as additional context.

### Milestone 3: Agentic AI

So far, you have provided the context of what is required to the LLM so that the LLM can infer if all the required values have been provided by the user input.

What if we remove the need for humans to interfere? Assume that the user ask the chat bot: I want to fill up this form (you can provide the HTML of the form since you will need to design the form but usually LLM will be able to access the form's HTML via url links) and provides the necessary unstructured data to fill up this form.

**Enhance your web UI to include an actual web form. You will need to design agentic AI in your server to reason and output answers based on the user prompt.**

Additional notes:
- To test if your AI agent is actually working, you should have two types of forms (A and B). The AI agent should reason itself which form is relevant (A or B) depending on the user input.

### Milestone 4: Extras

- Remove the need to provide form HTML. Let the AI agent retrieve the form.
- Instead of auto-populating form, try generate a URL that is able to auto-populate the form.
- To be continued...

## Restrictions

- You should use Python and Openai library for backend processing. You are free to use any database whenever required.
- You are highly encouraged use ReactJS to develop any user interface required.
- You should document this project as you go by updating the README with relevant instructions on how to setup & run this project. You should also document your solution to this problem.

> If these restrictions are too restrictive, feel free to propose to your mentor otherwise

## How to start?

You can start off by familiarizing yourself with openai APIs and other LLM libraries such as langchain. If you are unfamiliar with ReactJS or Python FastAPI, you should also read up on these frameworks as theese will be useful for your user interface and backend server respectively.

You should also setup a local LLM (eg. Ollama) so that you can start developing chat completions api.

> These are suggested solutions to this problem, you are welcome to propose other solutions to this problem.

## Resources

- [Open AI documentation](https://platform.openai.com/docs/guides/text?api-mode=responses)
- [Running Ollama locally](https://www.freecodecamp.org/news/how-to-run-open-source-llms-locally-using-ollama/)

