import React, { useState, useEffect } from 'react';
import { Form, Button, Dropdown, TextArea } from 'semantic-ui-react';
import { useLocation } from "react-router-dom";

const timezoneOptions = [
  { key: 'UTC+0', value: 'UTC+0', text: 'UTC (UTC+0)' }
]

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

function FormPage() {
  const [formData, setFormData] = useState({
    cityName: '',
    country: '',
    population: '',
    area: '',
    timezone: '',
    majorEvent: ''
  });

  const query = useQuery();

  useEffect(() => {
    const dataParam = query.get("data");
    if (!dataParam) return;

    fetch(`http://localhost:8000/form?data=${encodeURIComponent(dataParam)}`)
      .then((res) => {
        if (!res.ok) throw new Error("Bad response");
        return res.json();
      })
      .then((defaults) => {
        setFormData((f) => ({ ...f, ...defaults }));
      })
      .catch((err) => {
        console.error("Failed to load form defaults: ", err);
      });
  }, []);


  const handleChange = (e, { name, value}) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  }

  const handleSubmit = e => {
    e.preventDefault();
    console.log('Submitted data:', formData);
  }

  return (
    <Form onSubmit={handleSubmit} style ={{ maxWidth: '600px', margin: '2rem auto'}}>
      <Form.Field
        control={Form.Input}
        label='City Name'
        name='cityName'
        placeholder='Enter city name'
        value={formData.cityName}
        onChange={handleChange}
        required
      />

      <Form.Field
        control={Form.Input}
        label='Country'
        name='country'
        placeholder='Enter country'
        value={formData.country}
        onChange={handleChange}
        required
      />

      <Form.Group widths='equal'>
        <Form.Field
          control={Form.Input}
          type='number'
          label='Population'
          name='population'
          placeholder='Enter population number'
          value={formData.population}
          onChange={handleChange}
          required
        />

        <Form.Field
          control={Form.Input}
          type='number'
          label='Area (km^2)'
          name='area'
          placeholder='Enter area in km^2'
          value={formData.area}
          onChange={handleChange}
          required
      />
      </Form.Group>

      <Form.Field
        control={Dropdown}
        label='Timezone'
        name='timezone'
        placeholder='Select timezone'
        fluid
        search
        completion
        options={timezoneOptions}
        value={formData.timezone}
        onChange={handleChange}
        required
      />

      <Form.Field
        control={TextArea}
        label='Major Events'
        name='majorEvent'
        placeholder='Describe any major events'
        value={formData.majorEvent}
        onChange={handleChange}
      />

      <Form.Field control={Button} type='submit' primary>
        Submit
      </Form.Field>
    </Form>
  );
}

export default FormPage;