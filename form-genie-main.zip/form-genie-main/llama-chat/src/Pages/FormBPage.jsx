import React, { useState } from 'react';
import { Container, Form, Button, TextArea } from 'semantic-ui-react';

export default function UserFormPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    dateOfBirth: ''
  });

  const handleChange = (e, { name, value }) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    console.log('Submitted user info:', formData);
    // TODO: add submission logic (e.g. API call)
  };

  return (
    <Container style={{ marginTop: '2rem' }}>
      <Form onSubmit={handleSubmit} style={{ maxWidth: '600px', margin: 'auto' }}>
        <Form.Group widths='equal'>
          <Form.Input
            fluid
            label='First Name'
            name='firstName'
            placeholder='First Name'
            required
            value={formData.firstName}
            onChange={handleChange}
          />
          <Form.Input
            fluid
            label='Last Name'
            name='lastName'
            placeholder='Last Name'
            required
            value={formData.lastName}
            onChange={handleChange}
          />
        </Form.Group>

        <Form.Input
          fluid
          label='Email'
          name='email'
          type='email'
          placeholder='Email Address'
          required
          value={formData.email}
          onChange={handleChange}
        />

        <Form.Input
          fluid
          label='Phone Number'
          name='phone'
          type='tel'
          placeholder='+65 1234 5678'
          value={formData.phone}
          onChange={handleChange}
        />

        <Form.Field
          control={TextArea}
          label='Address'
          name='address'
          placeholder='Cintech II'
          value={formData.address}
          onChange={handleChange}
        />

        <Form.Input
          fluid
          label='Date of Birth'
          name='dateOfBirth'
          type='date'
          required
          value={formData.dateOfBirth}
          onChange={handleChange}
        />

        <Button primary type='submit'>
          Submit
        </Button>
      </Form>
    </Container>
  );
}
