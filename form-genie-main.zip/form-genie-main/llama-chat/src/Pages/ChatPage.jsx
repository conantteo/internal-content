import React, { useState } from 'react';
import { Container, Header, Form, Button, TextArea, Segment, Grid, Checkbox } from 'semantic-ui-react';

const API_URL = 'http://localhost:8000/test';

function ChatPage() {
  const [prompt, setPrompt] = useState('');
  const [responseText, setResponseText] = useState('');
  const [loading, setLoading] = useState(false);
  const [useStream, setUseStream] = useState(false);


  const generateResponse = async () => {
    const requestData = {
      user_input: prompt,
    };

    setLoading(true);
    setResponseText('');

    try {
      const url = `${API_URL}?stream=${useStream}`;
      const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
      });

      if (!res.ok) {
        const text = await res.text();
        setLoading(false);
        setResponseText(`Error: ${text}`);
        return;
      }

      if (useStream) {
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let done = false;
        while (!done) {
          const { value, done: streamDone } = await reader.read();
          done = streamDone;
          const chunk = decoder.decode(value);
          setResponseText((prev) => prev + chunk);
        }
      } else {
        const actualResponse = await res.json();
        setResponseText(actualResponse);
      }

    } catch(err) {
      console.error(err);
      setResponseText('An error occurred. Check the console.');
    } finally {
      setLoading(false);
      setPrompt('');
      const loadingSound = new Audio('/ding.mp3');
      loadingSound.play().catch((e) => console.warn(e));
    }
}

  return (
    <Container style={{ marginTop: '2rem' }}>
      <Header as="h1">FormGenie, here to help!</Header>

      <Form>
        <Form.Field>
          <Checkbox
            label="Stream Mode"
            checked={useStream}
            onChange={() => setUseStream((s) => !s)}
          />
        </Form.Field>
      </Form>

      <Grid stackable columns={2} divided style={{ marginTop: '2rem' }}>
        <Grid.Column>
          <Segment>
            <Header as="h2">Prompt:</Header>
            <Form onSubmit={(e) => { e.preventDefault(); generateResponse(); }}>
              <Form.Field>
                <TextArea
                  rows={3}
                  placeholder="Enter your prompt here..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
              </Form.Field>
              <Button primary type="submit" loading={loading} disabled={loading}>
                {loading ? 'Generating...' : 'Send'}
              </Button>
            </Form>
          </Segment>
        </Grid.Column>

        <Grid.Column>
          <Segment>
            <Header as="h2">Response:</Header>
            {responseText.trim().startsWith('http') ? (
              <a href={responseText.trim()} target="_blank" rel="noopener noreferrer">
                {responseText.trim()}
              </a>
            ) : (
              <Segment style={{ whiteSpace: 'pre-wrap', fontSize: '14px' }}>
                {responseText}
              </Segment>
            )}
          </Segment>
        </Grid.Column>
      </Grid>
    </Container>
  );
}

export default ChatPage;